#!/usr/bin/env bash
set -euo pipefail
echo "==> Installing prerequisites (Arch-first, falls back to apt/dnf)"
PKG=""
if command -v pacman >/dev/null 2>&1; then PKG="pacman"; fi
if command -v apt-get >/dev/null 2>&1; then PKG="apt"; fi
if command -v dnf >/dev/null 2>&1; then PKG="dnf"; fi

case "$PKG" in
  pacman)
    sudo pacman -Sy --noconfirm --needed python python-pip nginx openssl apache jq curl iproute2 wireguard-tools prometheus-node-exporter
    ;;
  apt)
    sudo apt-get update -y
    sudo apt-get install -y python3 python3-pip nginx openssl apache2-utils jq curl iproute2 wireguard prometheus-node-exporter
    ;;
  dnf)
    sudo dnf install -y python3 python3-pip nginx httpd-tools openssl jq curl iproute wireguard-tools prometheus-node-exporter
    ;;
  *)
    echo "WARN: Unknown package manager. Please install: python3, pip3, nginx, openssl, (apache2-utils/httpd-tools), jq, curl, iproute2, wireguard-tools, prometheus-node-exporter"
    ;;
esac

# Flask for the panel
if ! python3 -c "import flask" >/dev/null 2>&1; then
  sudo pip3 install --upgrade flask
fi

echo "==> Prereqs installed (or already present)."
