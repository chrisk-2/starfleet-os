#!/usr/bin/env bash
set -euo pipefail
enable="${1:-on}" # on/off
CONF=""
if [ -f /etc/nginx/sites-available/starfleet-panel.conf ]; then
  CONF="/etc/nginx/sites-available/starfleet-panel.conf"
elif [ -f /etc/nginx/conf.d/starfleet-panel.conf ]; then
  CONF="/etc/nginx/conf.d/starfleet-panel.conf"
fi
if [ -z "$CONF" ]; then
  echo "No nginx panel conf found"; exit 1
fi
if [ "$enable" = "on" ]; then
  # add rate limit map & zone at http{} level if not present
  if ! grep -q "limit_req_zone" /etc/nginx/nginx.conf; then
    sudo sed -i 's#http {#http {\n    limit_req_zone $binary_remote_addr zone=api_zone:10m rate=10r/s;#' /etc/nginx/nginx.conf
  fi
  # inject limit in server/location
  if ! grep -q "limit_req zone=api_zone" "$CONF"; then
    sudo awk '/location \//{print; print "        limit_req zone=api_zone burst=20 nodelay;"; next}1' "$CONF" | sudo tee "$CONF.tmp" >/dev/null
    sudo mv "$CONF.tmp" "$CONF"
  fi
  echo "Rate limiting enabled (10r/s, burst 20)."
else
  sudo sed -i '/limit_req_zone.*api_zone/d' /etc/nginx/nginx.conf || true
  sudo sed -i '/limit_req zone=api_zone .*;/d' "$CONF" || true
  echo "Rate limiting disabled."
fi
sudo nginx -t && sudo systemctl reload nginx
