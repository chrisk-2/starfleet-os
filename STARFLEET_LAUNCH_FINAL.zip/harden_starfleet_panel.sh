#!/usr/bin/env bash
set -euo pipefail
echo "==> Hardening: nginx TLS + BasicAuth + RBAC"

# Detect package manager
PKG=""
if command -v apt-get >/dev/null 2>&1; then PKG="apt"; fi
if command -v dnf >/dev/null 2>&1; then PKG="dnf"; fi
if command -v pacman >/devnull 2>&1; then PKG="pacman"; fi

case "$PKG" in
  apt) sudo apt-get update -y && sudo apt-get install -y nginx apache2-utils openssl jq ;;
  dnf) sudo dnf install -y nginx httpd-tools openssl jq ;;
  pacman) sudo pacman -Sy --noconfirm nginx apache jq openssl ;;
  *) echo "WARN: Unknown pkg manager; install nginx, openssl, and htpasswd manually." ;;
esac

sudo mkdir -p /etc/ssl/starfleet /etc/starfleet
if [ ! -f /etc/ssl/starfleet/starfleet.crt ]; then
  sudo openssl req -x509 -nodes -newkey rsa:2048 -days 365 -subj "/CN=starfleet.local" \
    -keyout /etc/ssl/starfleet/starfleet.key -out /etc/ssl/starfleet/starfleet.crt
fi

PASS="$(openssl rand -base64 18 | tr -d '\n' | head -c 18)"
if command -v htpasswd >/dev/null 2>&1; then
  if [ ! -f /etc/starfleet/htpasswd ]; then
    sudo htpasswd -bc /etc/starfleet/htpasswd ogre "$PASS"
  else
    sudo htpasswd -b /etc/starfleet/htpasswd ogre "$PASS"
  fi
  echo "==> BasicAuth user: ogre"
  echo "==> BasicAuth pass: $PASS"
fi

ENV_FILE="/etc/starfleet/controlpanel.env"
[ -f "$ENV_FILE" ] && . "$ENV_FILE" || true
if ! grep -q '^CONTROL_PANEL_VIEW_TOKEN=' "$ENV_FILE" 2>/dev/null; then
  VIEW="$(openssl rand -hex 16 2>/dev/null || echo viewtoken)"
  echo "CONTROL_PANEL_VIEW_TOKEN=$VIEW" | sudo tee -a "$ENV_FILE" >/dev/null
  echo "==> Added CONTROL_PANEL_VIEW_TOKEN to $ENV_FILE"
fi

if [ ! -f /etc/starfleet/roles.json ]; then
  sudo cp /mnt/data/roles.sample.json /etc/starfleet/roles.json
  if [ -f "$ENV_FILE" ]; then
    SUPER=$(grep '^CONTROL_PANEL_TOKEN=' "$ENV_FILE" | cut -d= -f2- | tr -d '\"')
    VIEW=$(grep '^CONTROL_PANEL_VIEW_TOKEN=' "$ENV_FILE" | cut -d= -f2- | tr -d '\"')
    jq --arg super "$SUPER" --arg view "$VIEW" '.tokens.SUPER.value=$super | .tokens.VIEW.value=$view' /etc/starfleet/roles.json | sudo tee /etc/starfleet/roles.json >/dev/null
  fi
  echo "==> Installed /etc/starfleet/roles.json"
fi

if [ -d /etc/nginx/sites-available ]; then
  sudo cp /mnt/data/nginx_starfleet_panel.conf /etc/nginx/sites-available/starfleet-panel.conf
  sudo ln -sf /etc/nginx/sites-available/starfleet-panel.conf /etc/nginx/sites-enabled/starfleet-panel.conf
  [ -f /etc/nginx/sites-enabled/default ] && sudo rm -f /etc/nginx/sites-enabled/default || true
else
  sudo cp /mnt/data/nginx_starfleet_panel.conf /etc/nginx/conf.d/starfleet-panel.conf
fi

sudo nginx -t
sudo systemctl enable --now nginx
sudo systemctl restart nginx

echo "==> Access: https://<host>/ (self-signed cert)"
echo "==> RBAC: /etc/starfleet/roles.json"
