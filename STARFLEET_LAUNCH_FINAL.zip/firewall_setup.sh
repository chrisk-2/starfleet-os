#!/usr/bin/env bash
set -euo pipefail
echo "==> Configuring firewall (nftables preferred)"
ALLOW_WG_PORT="${ALLOW_WG_PORT:-51820}"
if command -v nft >/dev/null 2>&1; then
  sudo bash -c "cat > /etc/nftables.conf" <<'EOF'
flush ruleset
table inet filter {
  chain input {
    type filter hook input priority 0;
    ct state established,related accept
    iif lo accept
    tcp dport {22,80,443} accept
    udp dport {80,443} accept
    udp dport 51820 accept
    icmp type echo-request accept
    counter drop
  }
}
EOF
  sudo systemctl enable --now nftables
  echo "nftables configured (22,80,443,51820,ICMP)."
elif command -v ufw >/dev/null 2>&1; then
  sudo ufw allow 22/tcp
  sudo ufw allow 80,443/tcp
  sudo ufw allow 51820/udp
  yes | sudo ufw enable || true
  sudo ufw status verbose
else
  echo "WARN: No nftables or ufw found. Skipping firewall."
fi
