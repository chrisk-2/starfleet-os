#!/usr/bin/env bash
set -euo pipefail
STAMP="$(date +%F-%H%M%S)"
OUT="/mnt/data/starfleet_backup_${STAMP}.tgz"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
echo "==> Backing up to $OUT"
sudo mkdir -p "$TMP/etc" "$TMP/app"
sudo cp -a /etc/starfleet "$TMP/etc/" 2>/dev/null || true
sudo cp -a /etc/nginx/sites-available/starfleet-panel.conf "$TMP/etc/" 2>/dev/null || true
sudo cp -a /etc/nginx/conf.d/starfleet-panel.conf "$TMP/etc/" 2>/dev/null || true
sudo cp -a /etc/ssl/starfleet "$TMP/etc/" 2>/dev/null || true
sudo cp -a /etc/wireguard "$TMP/etc/" 2>/dev/null || true
sudo cp -a /opt/starfleet-panel "$TMP/app/" 2>/dev/null || true
sudo tar -czf "$OUT" -C "$TMP" .
echo "$OUT"
