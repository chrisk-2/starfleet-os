#!/usr/bin/env bash
# Generate a WireGuard peer line from inputs
# Usage: ./generate_peer_line.sh <NAME> <PUBKEY> <HOST> <PORT> <ALLOWED_CIDR>
echo "${1:-NAME},${2:-PUBKEY},${3:-host},${4:-51820},${5:-10.31.0.X/32}"
