#!/usr/bin/env bash
set -euo pipefail
ARCHIVE="${1:-}"
[ -z "$ARCHIVE" ] && { echo "Usage: sudo bash restore_starafet.sh <backup.tgz>"; exit 1; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
sudo tar -xzf "$ARCHIVE" -C "$TMP"
sudo cp -a "$TMP/etc/." /etc/ || true
sudo cp -a "$TMP/app/." /opt/ || true
sudo systemctl daemon-reload
sudo systemctl restart nginx || true
sudo systemctl restart wg-quick@wg0 || true
sudo systemctl restart starfleet_controlpanel || true
echo "==> Restore complete."
