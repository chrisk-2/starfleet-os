#!/usr/bin/env bash
set -euo pipefail
read -r -p "This will stop the panel and proxy, and remove files under /opt/starfleet-panel and /etc/starfleet. Proceed? [y/N]: " GO
[[ ! "$GO" =~ ^[Yy]$ ]] && exit 0
sudo systemctl disable --now starfleet_controlpanel || true
sudo systemctl disable --now nginx || true
sudo rm -f /etc/systemd/system/starfleet_controlpanel.service
sudo systemctl daemon-reload
sudo rm -rf /opt/starfleet-panel /etc/starfleet
echo "==> Uninstall complete. You may also remove nginx/certs manually if desired."
