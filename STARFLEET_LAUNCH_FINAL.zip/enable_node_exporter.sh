#!/usr/bin/env bash
set -euo pipefail
if systemctl list-unit-files | grep -q prometheus-node-exporter.service; then
  sudo systemctl enable --now prometheus-node-exporter
  echo "==> Node exporter enabled."
else
  echo "WARN: prometheus-node-exporter not found. Install it via your package manager."
fi
