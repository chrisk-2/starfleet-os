#!/usr/bin/env bash
set -euo pipefail
HOST=${1:-localhost}
OUT=/mnt/data/health_report.txt
echo "StarfleetOS Health Report - $(date -Iseconds)" > "$OUT"
echo "Prometheus targets:" >> "$OUT"
curl -s http://$HOST:9090/api/v1/targets | jq '.data.activeTargets[] | {scrapeUrl, health, lastError}' >> "$OUT" || echo "Prometheus not reachable" >> "$OUT"
echo >> "$OUT"
echo "Grafana health:" >> "$OUT"
curl -s http://$HOST:3000/api/health >> "$OUT" || echo "Grafana not reachable" >> "$OUT"
echo >> "$OUT"
echo "Loki labels:" >> "$OUT"
curl -s "http://$HOST:3100/loki/api/v1/labels" >> "$OUT" || echo "Loki not reachable" >> "$OUT"
echo "Saved to $OUT"
