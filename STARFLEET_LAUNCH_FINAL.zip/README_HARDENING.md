# Hardening & RBAC — Starfleet Panel
One-shot:
```bash
sudo bash /mnt/data/harden_starfleet_panel.sh
```
Then open https://<host>/ (self-signed TLS). BasicAuth user **ogre** (password printed by the script).
Roles: edit `/etc/starfleet/roles.json`; restart `starfleet_controlpanel` afterwards.
