#!/usr/bin/env bash
set -euo pipefail
CN="${1:-starfleet-root-ca}"
CLIENT="${2:-ogre-client}"
SSL_DIR="/etc/ssl/starfleet"
sudo mkdir -p "$SSL_DIR"
cd "$SSL_DIR"

# Root CA
if [ ! -f ca.key ]; then
  openssl genrsa -out ca.key 4096
  openssl req -x509 -new -nodes -key ca.key -sha256 -days 3650 -subj "/CN=${CN}" -out ca.crt
fi

# Server CSR (reuse existing key if present)
if [ ! -f server.key ]; then
  openssl genrsa -out server.key 2048
fi
openssl req -new -key server.key -subj "/CN=$(hostname -f)" -out server.csr
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out server.crt -days 825 -sha256

# Client cert
openssl genrsa -out ${CLIENT}.key 2048
openssl req -new -key ${CLIENT}.key -subj "/CN=${CLIENT}" -out ${CLIENT}.csr
openssl x509 -req -in ${CLIENT}.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out ${CLIENT}.crt -days 825 -sha256

# Nginx config tweak: require client cert
CONF=""
if [ -f /etc/nginx/sites-available/starfleet-panel.conf ]; then
  CONF="/etc/nginx/sites-available/starfleet-panel.conf"
elif [ -f /etc/nginx/conf.d/starfleet-panel.conf ]; then
  CONF="/etc/nginx/conf.d/starfleet-panel.conf"
fi

if [ -n "$CONF" ]; then
  sudo sed -i 's#ssl_certificate\\s\\+/etc/ssl/starfleet/starfleet.crt;#ssl_certificate /etc/ssl/starfleet/server.crt;#' "$CONF"
  sudo sed -i 's#ssl_certificate_key\\s\\+/etc/ssl/starfleet/starfleet.key;#ssl_certificate_key /etc/ssl/starfleet/server.key;#' "$CONF"
  sudo awk "/server_name/{print; print \"    ssl_client_certificate /etc/ssl/starfleet/ca.crt;\\n    ssl_verify_client on;\"; next}1" "$CONF" | sudo tee "$CONF.tmp" >/dev/null
  sudo mv "$CONF.tmp" "$CONF"
  sudo nginx -t && sudo systemctl reload nginx
fi

echo "==> mTLS enabled. Distribute ${SSL_DIR}/${CLIENT}.crt and ${SSL_DIR}/${CLIENT}.key to clients; import CA: ${SSL_DIR}/ca.crt"
