#!/usr/bin/env bash
set -euo pipefail
STAMP="$(date +%F-%H%M%S)"
OUT="/mnt/data/starfleet_support_${STAMP}.tgz"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP"
( systemctl status starfleet_controlpanel nginx wg-quick@wg0 2>&1 || true ) > "$TMP/systemd_status.txt"
( journalctl -u starfleet_controlpanel -n 500 2>&1 || true ) > "$TMP/panel_journal.txt"
( journalctl -u nginx -n 500 2>&1 || true ) > "$TMP/nginx_journal.txt"
( wg show 2>&1 || true ) > "$TMP/wg_show.txt"
( curl -sS http://127.0.0.1:5080/version 2>/dev/null || true ) > "$TMP/panel_version.json"
( ls -l /etc/starfleet 2>&1 || true ) > "$TMP/etc_starfleet_ls.txt"
tar -czf "$OUT" -C "$TMP" .
echo "$OUT"
