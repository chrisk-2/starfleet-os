#!/usr/bin/env bash
set -euo pipefail
DOMAIN="${1:-}"
EMAIL="${2:-}"
if [[ -z "$DOMAIN" || -z "$EMAIL" ]]; then
  echo "Usage: sudo bash ./lets_encrypt_nginx.sh <domain> <email>"
  exit 1
fi
# Arch/Debian/Fedora differences for certbot
if command -v pacman >/dev/null 2>&1; then
  sudo pacman -Sy --noconfirm --needed certbot certbot-nginx
elif command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y && sudo apt-get install -y certbot python3-certbot-nginx
elif command -v dnf >/dev/null 2>&1; then
  sudo dnf install -y certbot python3-certbot-nginx
fi
# Update nginx server_name and reload
if [ -f /etc/nginx/sites-available/starfleet-panel.conf ]; then
  sudo sed -i "s/server_name _;/server_name ${DOMAIN};/" /etc/nginx/sites-available/starfleet-panel.conf || true
  sudo nginx -t && sudo systemctl reload nginx
elif [ -f /etc/nginx/conf.d/starfleet-panel.conf ]; then
  sudo sed -i "s/server_name _;/server_name ${DOMAIN};/" /etc/nginx/conf.d/starfleet-panel.conf || true
  sudo nginx -t && sudo systemctl reload nginx
fi
# Obtain and install cert
sudo certbot --nginx -d "$DOMAIN" -m "$EMAIL" --agree-tos --non-interactive --redirect
echo "==> Let's Encrypt installed for $DOMAIN. Auto-renew is handled by certbot.timer."
