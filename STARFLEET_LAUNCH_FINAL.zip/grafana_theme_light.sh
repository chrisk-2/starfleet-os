#!/usr/bin/env bash
set -euo pipefail
echo "GF_USERS_DEFAULT_THEME=light" > /srv/grafana/grafana.env
docker restart grafana 2>/dev/null || true
podman restart grafana 2>/dev/null || true
echo "[*] Grafana set to light theme."
