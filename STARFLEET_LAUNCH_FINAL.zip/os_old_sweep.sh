#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
KEEP=(
  "install_prereqs.sh"
  "install_starfleet_panel.sh"
  "harden_starfleet_panel.sh"
  "starfleet_controlpanel.service"
  "control_panel_authed.py"
  "control_panel_lcars_embed.html"
  "full_system_snapshot.sh"
  "starfleet_panel_curl.sh"
  "LCARSControlPanel.tsx"
  "roles.sample.json"
  "nginx_starfleet_panel.conf"
  "Caddyfile"
  "README_CONTROL_PANEL.md"
  "README_HARDENING.md"
  "README_LAUNCH.md"
  "wg_mesh_setup.sh"
  "enable_node_exporter.sh"
  "starfleet_self_test.sh"
  "grafana_theme_dark.sh"
  "grafana_theme_light.sh"
  "health_report.sh"
)
mkdir -p "$ROOT/OS_OLD"
echo "==> Sweeping $ROOT ..."
shopt -s nullglob
for f in "$ROOT"/*; do
  base="$(basename "$f")"
  match=0
  for k in "${KEEP[@]}"; do
    if [[ "$base" == "$k" ]]; then match=1; break; fi
  done
  if [[ $match -eq 0 && -f "$f" ]]; then
    echo " moving $base -> OS_OLD/"
    mv "$f" "$ROOT/OS_OLD/"
  fi
done
echo "==> Sweep complete."
