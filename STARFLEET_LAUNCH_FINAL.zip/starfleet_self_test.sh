#!/usr/bin/env bash
set -euo pipefail
echo "==> Starfleet Post-Install Self-Test"
# Panel
echo "[1/6] Checking service..."
systemctl is-active --quiet starfleet_controlpanel && echo " OK: service active" || { echo " FAIL: service not active"; systemctl status starfleet_controlpanel --no-pager -l; exit 1; }
# Ping
echo "[2/6] Ping endpoint..."
curl -sS http://127.0.0.1:5080/ping | jq . >/dev/null || { echo " FAIL: ping"; exit 1; }
# Token
echo "[3/6] Token retrieval..."
TOKEN=$(sudo awk -F= '/^CONTROL_PANEL_TOKEN=/{print $2}' /etc/starfleet/controlpanel.env)
test -n "$TOKEN" || { echo " FAIL: token missing"; exit 1; }
# Theme flip dry test (won't fail panel if scripts missing)
echo "[4/6] Grafana theme flip (safe test)..."
curl -sS -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:5080/grafana/dark | jq . >/dev/null || echo " WARN: theme flip failed (ok if Grafana not present)"
# Health check
echo "[5/6] Health report..."
curl -sS -X POST -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"host":"localhost"}' http://127.0.0.1:5080/health | jq . >/dev/null || echo " WARN: health report failed (ok if scripts/env not ready)"
# Snapshot
echo "[6/6] Snapshot..."
curl -sS -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:5080/snapshot | jq . >/dev/null || echo " WARN: snapshot failed"
echo "==> Self-test complete."
