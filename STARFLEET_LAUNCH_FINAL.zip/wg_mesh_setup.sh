#!/usr/bin/env bash
# WireGuard Mesh Bootstrap — creates wg0, generates keys if needed, and enables service.
# Usage:
#   sudo bash ./wg_mesh_setup.sh --role <INSPIRON|OPTIPLEX> --peer "<Name>,<PublicKey>,<EndpointHost>,<EndpointPort>,<AllowedIPs>"
# Example:
#   sudo bash ./wg_mesh_setup.sh --role INSPIRON \
#     --peer "OPTIPLEX,ABCD...,optiplex.lan,51820,10.31.0.2/32" \
#     --address 10.31.0.1/24
set -euo pipefail
ROLE="node"
ADDRESS="10.31.0.1/24"
PEERS=()
LISTEN_PORT="${WG_LISTEN_PORT:-51820}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --role) ROLE="$2"; shift 2;;
    --peer) PEERS+=("$2"); shift 2;;
    --address) ADDRESS="$2"; shift 2;;
    --listen) LISTEN_PORT="$2"; shift 2;;
    *) echo "Unknown arg: $1"; exit 1;;
  esac
done

sudo mkdir -p /etc/wireguard
cd /etc/wireguard

if [ ! -f privatekey ]; then
  umask 077
  wg genkey | tee privatekey | wg pubkey > publickey
fi

PRIV=$(cat privatekey)
PUB=$(cat publickey)

cat > wg0.conf <<EOF
[Interface]
Address = ${ADDRESS}
ListenPort = ${LISTEN_PORT}
PrivateKey = ${PRIV}
SaveConfig = true

EOF

for P in "${PEERS[@]}"; do
  # CSV: Name,PublicKey,EndpointHost,EndpointPort,AllowedIPs
  IFS=',' read -r NAME PK HOST PORT ALLOWED <<< "$P"
  cat >> wg0.conf <<EOP

# Peer: ${NAME}
[Peer]
PublicKey = ${PK}
Endpoint = ${HOST}:${PORT}
AllowedIPs = ${ALLOWED}
PersistentKeepalive = 25
EOP
done

sudo systemctl enable --now wg-quick@wg0
echo "==> WireGuard up. Local public key:"
cat publickey
